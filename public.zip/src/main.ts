import MarkdownParser from './components/parser'
import path from 'path'
import MakeHTML from './components/make-html'
import MakeIndex from './components/make-index'
import fs from 'fs'

const parser = new MarkdownParser();

const seekBaseDir = './site';
const extFilter = 'md';

const extension = (element: string) => {
    var extName = path.extname(element);
    return extName === '.' + extFilter;
};

const parse = async (filepath: string) => {

    parser.readTarget(filepath, '##').then((vals)=>{
        vals.forEach((elem, idx) => {
            // splitted file
            const path = `${filepath}.${idx}.html`;
            // convert to html.
            const parsed = MakeHTML.make(parser.parseStr(elem));
            fs.writeFileSync(path, parsed);
        });
    })
}

function seekDir(dirpath: string) {
    fs.readdir(dirpath, function (err, list) {
        if (list !== undefined) {
            list.filter(extension).forEach(function (value) {
                console.log(dirpath + "/" + value);
                //TODO Make Markdown.
                parse(path.resolve(dirpath, value))
            });

            list.forEach(function (value) {
                let nextDir: string = dirpath + "/" + value;
                if (fs.statSync(nextDir).isDirectory()) {
                    seekDir(nextDir);
                }
            });
        }
    });
}

seekDir(seekBaseDir);